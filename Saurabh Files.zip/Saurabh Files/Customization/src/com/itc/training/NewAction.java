package com.itc.training;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.itc.training.NewAction")
public class NewAction extends WTListResourceBundle {
	 @RBEntry("Open Action")
	            //@RBComment("ViewJSP")
	  public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC = "lmn.OpenMenu.description";
	            
	  
	   @RBEntry("export_BOM_to_CEDM.png")
	     public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON = "lmn.OpenMenu.icon";
	                        
	          @RBEntry("This action is to view")
	             public static final String LOCK_CI_BY_CHANGE_NOTICE_TOOLTIP = "lmn.OpenMenu.tooltip";
}
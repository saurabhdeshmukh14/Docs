package com.itc.validator;

import com.ptc.core.ui.validation.DefaultSimpleValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;

import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;

public class CustomSimpleFilter extends DefaultSimpleValidationFilter {
@Override 
public UIValidationStatus preValidateAction(UIValidationKey paramUIValidationKey,
		UIValidationCriteria paramUIValidationCriteria) {
	// TODO Auto-generated method stub 
	UIValidationStatus status= UIValidationStatus.DISABLED;
	try {
	WTPrincipal principal=SessionHelper.getPrincipal();
	System.out.println("Simple Filter is called--- " + paramUIValidationKey + "----" +principal.getName());
@SuppressWarnings("deprecation")
WTGroup group=OrganizationServicesHelper.manager.getGroup("Administrators");
	
	if(group.isMember(principal)) {
		status=UIValidationStatus.ENABLED;
	}
	}catch(WTException exception) {
		exception.printStackTrace();
	}
	System.out.println("status----"+status);
	return status;
	
}
}

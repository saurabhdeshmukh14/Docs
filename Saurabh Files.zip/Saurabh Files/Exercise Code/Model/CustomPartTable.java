package com.itc.training;

import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.util.WTException;

/**
 * 
 * @author Anjali Sharma
 *
 */

@ComponentBuilder("com.itc.training.CustomPartTable")
public class CustomPartTable extends AbstractComponentBuilder {

	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		QuerySpec qSpec = new QuerySpec(WTPart.class);
		QueryResult qResult = PersistenceHelper.manager.find(qSpec);
		return qResult;
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		
		ComponentConfigFactory componentConfigFactory = this.getComponentConfigFactory();
		TableConfig table = componentConfigFactory.newTreeConfig();
		
		ColumnConfig name = componentConfigFactory.newColumnConfig("name", true);
		ColumnConfig number = componentConfigFactory.newColumnConfig("number", true);
		ColumnConfig status = componentConfigFactory.newColumnConfig("status", true);
		ColumnConfig revision = componentConfigFactory.newColumnConfig("revision", true);
		
		table.setLabel("My Test Table");
		table.addComponent(name);
		table.addComponent(number);
		table.addComponent(status);
		table.addComponent(revision);
		
		return table;
	}

}

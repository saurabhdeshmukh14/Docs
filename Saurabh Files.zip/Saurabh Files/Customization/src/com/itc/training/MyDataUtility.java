package com.itc.training;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.guicomponents.IconComponent;

import wt.part.WTPart;
import wt.util.WTException;

public class MyDataUtility extends AbstractDataUtility{

	@Override
	public Object getDataValue(String str, Object object, ModelContext mc) throws WTException {
		WTPart part = (WTPart)object;
		String state = part.getLifeCycleState().toString();
		String image;
		if(state.equals("INWORK"))
		{
			
			image="netmarkets/images/red.gif";
		}
		else if(state.equals("RELEASED"))
		{
			
			image="netmarkets/images/green.gif";
		}
		else
		{
			
			image="netmarkets/images/yellow.gif";
		}
		IconComponent icon = new IconComponent(image);
		
		return icon;
	}

}

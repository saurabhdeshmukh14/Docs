package com.itc.training;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.ComboBox;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.enterprise.participant.jaxb.Role;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.wpcfg.halocal.LocalContainer;

import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.pdmlink.PDMLinkProduct;
import wt.session.SessionHelper;
import wt.util.WTException;

public class AssignmentDU extends DefaultDataUtility{

	@Override
	public Object getDataValue(String componentId, Object object, ModelContext mContext) throws WTException {
		
		System.out.println("Component ID"+componentId);
		System.out.println("Object"+object);
		System.out.println("Model Context"+mContext);
		
		/*ComboBox comboBox = new ComboBox();
		Object obj = super.getDataValue(componentId, object, mContext);
		if(obj instanceof AttributeInputCompositeComponent)
		{
			if(mContext.getDescriptorMode().equals(ComponentMode.CREATE))
			{	
				ArrayList<String> displaylist = new ArrayList<String>();
				displaylist.add("Customization Training -2018");
				displaylist.add("Customization Training -2019");
				
				comboBox.setValues(displaylist);	
			 
			
		}
			comboBox.setColumnName(AttributeDataUtilityHelper.getColumnName(componentId, object, mContext));
			
		}	*/
		Object obj = super.getDataValue(componentId, object, mContext);
		if(obj instanceof AttributeInputCompositeComponent)
		{
			if(mContext.getDescriptorMode().equals(ComponentMode.EDIT))
				System.out.println("here-----------------");
			 
			
		}
		/*if(mContext.getDescriptorMode().equals(ComponentMode.EDIT)){
			System.out.println("In method");
			ObjectIdentifier oid = ObjectIdentifier.newObjectIdentifier("wt.pdmlink.PDMLinkProduct:'ITC PART'");
			PDMLinkProduct prod = (PDMLinkProduct) PersistenceHelper.manager.refresh(oid);
			ContainerTeam team = ContainerTeamHelper.service.getContainerTeam(prod);
			            
			HashMap test= team.getAllMembers();
			WTUser user = (WTUser)SessionHelper.manager.getPrincipal();
			if(test.containsKey(user)){
				   System.out.println("users---->"+test);
			}else{
				System.out.println("user not present");
			}
		}*/
		return obj;
		
		
	}
		

}

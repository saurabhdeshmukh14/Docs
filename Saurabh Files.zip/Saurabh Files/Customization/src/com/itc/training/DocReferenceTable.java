package com.itc.training;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ptc.core.components.suggest.SuggestResult;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartReferenceLink;
import wt.util.WTException;
@ComponentBuilder("com.itc.training.DocReferenceTable")
public class DocReferenceTable extends AbstractComponentBuilder {

	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		List<WTDocument> list = new ArrayList<WTDocument>();
		WTPart part = (WTPart) arg1.getContextObject();
		System.out.println("In DOCREFERENCE");
		QueryResult qr = PersistenceHelper.manager.navigate(part,WTPartDescribeLink.DESCRIBED_BY_ROLE,wt.part.WTPartDescribeLink.class,false);
		 
		while (qr.hasMoreElements()){
			WTPartDescribeLink link = (WTPartDescribeLink)qr.nextElement();
			System.out.println("Found link ..........." + link);
			WTDocument doc = link.getDescribedBy();
			System.out.println("Described By Document ...."+ doc.getNumber());
			list.add((WTDocument) doc);
		}
		QueryResult qr1 = PersistenceHelper.manager.navigate(part,WTPartReferenceLink.REFERENCES_ROLE, wt.part.WTPartReferenceLink.class,false);
		 
		while (qr1.hasMoreElements()){
			WTPartReferenceLink link = (WTPartReferenceLink)qr.nextElement();
			System.out.println("Found link ..........." + link);
			WTDocumentMaster doc = link.getReferences();
			
			System.out.println("Referenced By Document ...."+ doc.getNumber());
		}
		//WTPart xyz = (WTPart) arg1.getContextObject();
		return list;
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		
		ComponentConfigFactory componentConfigFactory = this.getComponentConfigFactory();
		TableConfig table = componentConfigFactory.newTreeConfig();
		ColumnConfig name = componentConfigFactory.newColumnConfig("name", true);
		ColumnConfig containername = componentConfigFactory.newColumnConfig("containerName", true);
		ColumnConfig state = componentConfigFactory.newColumnConfig("state", true);
		ColumnConfig version = componentConfigFactory.newColumnConfig("version", true);
		
		table.setLabel("Doc Reference");
		table.addComponent(name);
		table.addComponent(containername);
		table.addComponent(state);
		table.addComponent(version);
		
		return table;
		
	}

}

package com.itc.training;

import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

import net.sf.saxon.query.QueryResult;
import wt.fc.PersistenceHelper;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.util.WTException;

@ComponentBuilder("com.itc.training.DemoTable")
public class customtabtable extends AbstractComponentBuilder{

	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		QuerySpec qspec= new QuerySpec(WTPart.class);
		wt.fc.QueryResult qResult = PersistenceHelper.manager.find(qspec);		
		return qResult;
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		ComponentConfigFactory componentConfigFactory = this.getComponentConfigFactory();
			
		TableConfig table = componentConfigFactory.newTreeConfig();
		ColumnConfig name = componentConfigFactory.newColumnConfig("name", true);
		ColumnConfig number = componentConfigFactory.newColumnConfig("number", true);
		ColumnConfig state = componentConfigFactory.newColumnConfig("state.state", true);
		state.setDataUtilityId("MyID");
		ColumnConfig revision = componentConfigFactory.newColumnConfig("revision", true);
		
		table.setLabel("DEMO TABLE");
		table.addComponent(name);
		table.addComponent(number);
		table.addComponent(state);
		table.addComponent(revision);
		
		return table;
	
	}

}

package com.itc.training;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.itc.training.xyz")
public class xyz extends WTListResourceBundle {
	 @RBEntry("Cutom_Part")
	            //@RBComment("ViewJSP")
	  public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC1 = "pqr.createPartxyz.description";
	            
	  
	   @RBEntry("export_BOM_to_CEDM.png")
	     public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON1 = "pqr.createPartxyz.icon";
	                        
	          @RBEntry("This action is to view")
	             public static final String LOCK_CI_BY_CHANGE_NOTICE_TOOLTIP1 = "pqr.createPartxyz.tooltip";
	          
	  /*  @RBEntry("Custom_Part")
	            //@RBComment("ViewJSP")
	  public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC1 = "saurabh.createPartxyz.description";
	            
	  
	   @RBEntry("export_BOM_to_CEDM.png")
	     public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON1 = "saurabh.createPartxyz.icon";*/
	                                 
}
package com.itc.processor;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;

public class CreateObjectFormProcessor extends DefaultObjectFormProcessor {
	@Override
	@Deprecated
	public FormResult doOperation(NmCommandBean commandBean, List<ObjectBean> list) throws WTException {
		System.out.println("In Do Operation");
		HttpServletRequest request = commandBean.getRequest();
		String type = request.getParameter("Type");
		@SuppressWarnings("rawtypes")
		HashMap map = commandBean.getText();
		Object[] keys = map.keySet().toArray();
		String name = null;
		String number = null;
		String containerOid = null;
		String folderOid = null;
		for (Object oneSet : keys) {
			if (((String) oneSet).equals("name")) {
				name = ((String) map.get(oneSet)).toUpperCase();
			} else if (((String) oneSet).equals("loc_folder")) {
				folderOid = (String) map.get(oneSet);
			} else if (((String) oneSet).equals("loc_container")) {
				containerOid = (String) map.get(oneSet);
			} else if (((String) oneSet).equals("number")) {
				number = (String) map.get(oneSet);
			}
		}
		
		Persistable per = null;
		if (type.toLowerCase().contains("part")) {
			per = createPart(name, number, containerOid, folderOid);
		} else if (type.toLowerCase().contains("document")) {
			per = createDocument(name, number, containerOid, folderOid);
		} else {
			throw new WTException("Select a valid object type");
		}
		ObjectBean ob = ObjectBean.newInstance();
		ob.setObject(per);
		list.add(ob);
		return super.doOperation(commandBean, list);
	}
	
 @Override
	public WTMessage getSuccessMessageTitle() {
		return new WTMessage("com.ptc.core.ui.successMessagesRB",
		"OBJECT_CREATE_SUCCESSFUL_TITLE", (Object[]) null);
		}
 
 
	private Persistable createDocument(String name, String number, String containerOid, String folderOid)
			throws WTException {
		WTDocument doc = WTDocument.newWTDocument();
		try {
			doc.setName(name);
			doc.setNumber(number);

			doc.setContainer((WTContainer) fromReferenceToObject(containerOid));
			assignFolder(doc, folderOid);
			doc = (WTDocument) PersistenceHelper.manager.save(doc);
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		}
		return doc;
	}

	private Persistable createPart(String name, String number, String containerOid, String folderOid)
			throws WTException {
		WTPart part = WTPart.newWTPart();
		try {
			part.setName(name); 
			part.setNumber(number);
			part.setContainer((WTContainer) fromReferenceToObject(containerOid));
			assignFolder(part, folderOid);
			part = (WTPart) PersistenceHelper.manager.save(part);
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		}
		return part;
	}

	private Persistable fromReferenceToObject(String objectReference) throws WTException {
		final ReferenceFactory factory = new ReferenceFactory();
		final ObjectReference objRef = (ObjectReference) factory.getReference(objectReference);
		return (objRef.getObject());
	}

	@Override
	public FormResult preProcess(NmCommandBean arg0, List<ObjectBean> arg1) throws WTException {
			System.out.println("in the pre process");
			HashMap map = arg0.getText();
			Object[] keys = map.keySet().toArray();
			String name = null; 
			String number = null;
			String containerOid = null;
			String folderOid = null; 
			for (Object key : keys) {
				System.out.println("key---"+key);
				if (((String) key).equals("name")) {
					name = ((String) map.get(key)).toUpperCase();
				} else if (((String) key).equals("loc_folder")) {
					folderOid = (String) map.get(key);
				} else if (((String) key).equals("loc_container")) {
					containerOid = (String) map.get(key);
				} else if (((String) key).equals("number")) {
					number = (String) map.get(key);
				}
			}
			if (name == null || number == null || name.isEmpty() || number.isEmpty()) {
				throw new WTException("Provide value for Name and Number"); 
			} else if (folderOid == null || containerOid == null || folderOid.isEmpty() || containerOid.isEmpty()) {
				throw new WTException(
						"Select the location properly by clicking on Browse button kindly don't copy paste it");
			}
			if (number.length() < 6) {
				throw new WTException("Please enter a number greater than 6 digits");
			}
		return super.preProcess(arg0, arg1); 
	}

	@Override
	public FormResult postProcess(NmCommandBean arg0, List<ObjectBean> arg1) throws WTException {
		System.out.println("In Post Process, after do operation");
		return super.postProcess(arg0, arg1);
	}

	private void assignFolder(FolderEntry folderEntry, String folderOid) throws WTException {
		final Folder folder = ((Folder) fromReferenceToObject(folderOid));
		FolderHelper.assignLocation(folderEntry, folder);
	}
	
	@Override
	public FormResult postTransactionProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList)
			throws WTException {
		// TODO Auto-generated method stub
		System.out.println("In Post transaction Process, after do operation");
		return super.postTransactionProcess(paramNmCommandBean, paramList);
	}
}

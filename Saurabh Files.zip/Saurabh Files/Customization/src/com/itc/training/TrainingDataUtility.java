package com.itc.training;

import java.util.ArrayList;

import com.ptc.core.components.descriptor.ComponentModel;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.ComboBox;
import com.ptc.core.ui.resources.ComponentMode;

import wt.util.WTException;

public class TrainingDataUtility extends DefaultDataUtility {

	@Override
	public Object getDataValue(String componentId, Object object, ModelContext mContext) throws WTException {
		
		System.out.println("Component ID"+componentId);
		System.out.println("Object"+object);
		System.out.println("Model Context"+mContext);
		
		ComboBox comboBox = new ComboBox();
		Object obj = super.getDataValue(componentId, object, mContext);
		if(obj instanceof AttributeInputCompositeComponent)
		{
			if(mContext.getDescriptorMode().equals(ComponentMode.CREATE))
			{	
				ArrayList<String> displaylist = new ArrayList<String>();
				displaylist.add("Customization Training -2018");
				displaylist.add("Customization Training -2019");
				
				comboBox.setValues(displaylist);	
			 
			
		}
			comboBox.setColumnName(AttributeDataUtilityHelper.getColumnName(componentId, object, mContext));
			
		}	
		return comboBox;
		
		
	}
		

}


package com.itc.training;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.rendering.guicomponents.Label;

import wt.part.WTPart;
import wt.util.WTException;


public class CutomDataUtility extends AbstractDataUtility{
	
		//@Override
			public Object getDataValue(String str, Object obj, ModelContext modelContext) throws WTException {
				Label name = new Label("");
				name.setColumnName(AttributeDataUtilityHelper.getColumnName(str, obj,  modelContext));
				name.setId(str);
				WTPart part = (WTPart) obj;
				name.setValue(part.getName() + "["+part.getNumber()+"]");
				return name;
			}
		
}

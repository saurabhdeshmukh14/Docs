package com.itc.training;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.RadioButton;
import com.ptc.core.components.rendering.guicomponents.RadioButtonGroup;

import wt.util.WTException;

public class WeatherDataUtility extends DefaultDataUtility{
	
	public Object getDataValue(String componentId, Object obj, ModelContext mc) throws WTException
	{
		RadioButtonGroup radiobuttongroup = new RadioButtonGroup();
		com.ptc.core.components.rendering.guicomponents.RadioButton spring = new RadioButton();
		
		spring.setLabel("Spring");
		spring.setValue("Spring");
		spring.setRenderLabel(true);
		com.ptc.core.components.rendering.guicomponents.RadioButton winter = new RadioButton();
		winter.setLabel("Winter");
		winter.setValue("Winter");
		winter.setRenderLabel(true);
		radiobuttongroup.addButton(winter);
		radiobuttongroup.addButton(spring);
		
		radiobuttongroup.setColumnName(AttributeDataUtilityHelper.getColumnName(componentId, obj, mc));
		return radiobuttongroup;
	}
	

}

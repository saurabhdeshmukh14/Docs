package com.itc.training;

import com.ptc.enterprise.slickum.model.QuerySpec;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

import net.sf.saxon.query.QueryResult;
import wt.fc.PersistenceHelper;
import wt.part.WTPart;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.util.WTException;
import wt.vc.config.ConfigHelper;

@ComponentBuilder("com.itc.training.CustomPartTable")
public class CustomPartTable extends AbstractComponentBuilder{
	
	@SuppressWarnings("deprecation")
	@Override
	public Object buildComponentData(ComponentConfig var1, ComponentParams var2) throws Exception {
		// TODO Auto-generated method stub
		/*wt.query.QuerySpec qspec = new wt.query.QuerySpec(WTPart.class);
		
		wt.fc.QueryResult qresult = PersistenceHelper.manager.find(qspec);
		return qresult;*/
		WTPart xyz = (WTPart) var2.getContextObject();
		//wt.query.QuerySpec querySpec = new wt.query.QuerySpec(WTPart.class);
			//querySpec.appendWhere((WhereExpression) new SearchCondition(WTPart.class,WTPart.NAME, SearchCondition.LIKE,"Maruti%"));
			//wt.fc.QueryResult qr = PersistenceHelper.manager.find(querySpec);
			
			
		return xyz;
		}
	


	@Override
	public ComponentConfig buildComponentConfig(ComponentParams var1) throws WTException {
		// TODO Auto-generated method stub
		ComponentConfigFactory componentConfigFactory = this.getComponentConfigFactory();
		TableConfig table = componentConfigFactory.newTreeConfig();
		
		ColumnConfig name = componentConfigFactory.newColumnConfig("name", true);
		ColumnConfig number = componentConfigFactory.newColumnConfig("number", true);
		ColumnConfig status = componentConfigFactory.newColumnConfig("state.state", true);
		ColumnConfig revision = componentConfigFactory.newColumnConfig("revision", true);
		
		table.setLabel("My Test Table");
		table.addComponent(name);
		table.addComponent(number);
		table.addComponent(status);
		table.addComponent(revision);
		
		return table;
	}

}

package com.itc.training;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.google.gwt.resources.css.ast.CssProperty.StringValue;
import com.ptc.core.components.suggest.SuggestParms;
import com.ptc.core.components.suggest.SuggestResult;
import com.ptc.core.components.suggest.Suggestable;
import com.ptc.core.foundation.occurrence.server.impl.ContextReferenceAttributeHandler;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinitionMaster;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.iba.definition.StringDefinition;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.util.WTException;

public class SuggestTextHelper implements Suggestable {
	public Collection<SuggestResult> getSuggestions(SuggestParms suggestParams) { // Override function
		List<SuggestResult> list = new ArrayList<SuggestResult>();
		/*try {
			String partNumber = suggestParams.getSearchTerm().toUpperCase() + "%";
			System.out.println("partNumber--"+partNumber);
			QuerySpec spec = new QuerySpec();
			int partIndex=spec.appendClassList(WTPart.class, true);
			int typeindex= spec.appendClassList(WTTypeDefinition.class, false);
			int typemindex=spec.appendClassList(WTTypeDefinitionMaster.class, false);
			int string1=spec.appendClassList(StringValue.class, false);
			int string2=spec.appendClassList(StringDefinition.class, false);
		
			SearchCondition number = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.LIKE,
					partNumber, false);
			spec.appendWhere(number, new int[] {partIndex});
			spec.appendAnd(); 
			spec.appendWhere(new SearchCondition(WTPart.class, "typeDefinitionReference.key.id",WTTypeDefinition.class,"thePersistInfo.theObjectIdentifier.id"), new int[] {partIndex,typeindex});
			spec.appendAnd();
			spec.appendWhere(new SearchCondition(WTTypeDefinition.class, WTTypeDefinition.MASTER_REFERENCE+".key.id",WTTypeDefinitionMaster.class,"thePersistInfo.theObjectIdentifier.id"), new int[]{typeindex,typemindex});
			spec.appendAnd();
			spec.appendWhere(new SearchCondition(WTTypeDefinition.class, WTTypeDefinition.NAME,SearchCondition.EQUAL,"com.itcinfotech.itcnp.ITCAutomobiles.ITCPart"), new int[]{typeindex});
			spec.appendAnd();
		//	spec.appendWhere(new SearchCondition(StringValue.class, "theIBAHolderReference.key.id",StringDefinition.class,"wt.iba.definition.StringDefinitionReference "),new int[]{string1,string2});
		//	spec.appendAnd();
		//	spec.appendWhere(new SearchCondition(StringValue.class, StringValue,SearchCondition.EQUAL,"com.itcinfotech.itcnp.ITCAutomobiles.ITCPart"), new int[]{typeindex});
			QueryResult result = PersistenceHelper.manager.find(spec);
			System.out.println("qs--"+spec.toString());
			WTPart part = null; 
			while(result.hasMoreElements()) {
				Object[] object = (Object[]) result.nextElement();
				part =(WTPart) object[0];
				list.add(SuggestResult.valueOf(part.getNumber(), part.getName()));
			}
		} catch (WTException wte) {
			wte.printStackTrace();
		}*/
			try{
			String partNumber = suggestParams.getSearchTerm().toUpperCase() + "%";		
				QuerySpec spec = new QuerySpec();
				int partIndex=spec.appendClassList(WTPart.class, true); 
				int stringval = spec.addClassList(wt.iba.value.StringValue.class, false);
				int stringdef =spec.addClassList(StringDefinition.class,false);
				//int partindexM = spec.addClassList(WTPartMaster.class, false);
				
				SearchCondition number = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.LIKE,	partNumber, false);
				spec.appendWhere(number,new int[] {partIndex});
				spec.appendAnd();
				//System.out.println("qs--"+spec.toString());
				spec.appendWhere(new SearchCondition(wt.iba.value.StringValue.class, "definitionReference.key.id",StringDefinition.class,"thePersistInfo.theObjectIdentifier.id"), new int[] {stringval,stringdef});
				spec.appendAnd();
				//System.out.println("qs--"+spec.toString());
				spec.appendWhere(new SearchCondition(WTPart.class, "thePersistInfo.theObjectIdentifier.id",wt.iba.value.StringValue.class,"theIBAHolderReference.key.id"), new int[] {partIndex,stringval});
				spec.appendAnd();
				//System.out.println("qs--"+spec.toString());
				spec.appendWhere(new SearchCondition(StringDefinition.class,StringDefinition.DISPLAY_NAME,SearchCondition.EQUAL,"Combo"),new int[] {stringdef});
				spec.appendAnd();
				//System.out.println("qs--"+spec.toString());
				spec.appendWhere(new SearchCondition(wt.iba.value.StringValue.class,wt.iba.value.StringValue.VALUE,SearchCondition.EQUAL,"TYPE C"),new int[] {stringval});
				//spec.appendAnd();
				//System.out.println("qs--"+spec.toString());
				/*spec.appendWhere(new SearchCondition(WTPartMaster.class, "thePersistInfo.theObjectIdentifier.id",WTPart.class,"masterReference.key.id"), new int[] {partindexM,partIndex});
				System.out.println("qs--"+spec.toString());*/
				QueryResult result = PersistenceHelper.manager.find(spec);
				//System.out.println("qs--"+spec.toString());
				WTPart part = null; 
				while(result.hasMoreElements()) {
					Object[] object = (Object[]) result.nextElement();
					part =(WTPart) object[0];
					list.add(SuggestResult.valueOf(part.getNumber(), part.getName()));
			}
		return list;
	}catch (WTException wte) {
		wte.printStackTrace();
	}
			return list;
			}
}

package com.itc.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.RBPseudo;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.itc.resource.CustomResourceRB")
public class CustomResourceRB extends WTListResourceBundle {
	
	@RBEntry("Create Object")
	public static final String CONSTANT_1="part.createPartCustom.description";
	
	@RBEntry("Create Object")
	public static final String CONSTANT_2="part.createPartCustom.title";
	 
	@RBEntry("Create Object action")
	public static final String CONSTANT_3="part.createPartCustom.tooltip";
	
	@RBEntry("attributes.gif")
	@RBPseudo(false)
	public static final String CONSTANT_4="part.createPartCustom.icon";	
	
	
	@RBEntry("Part Information")
	public static final String CONSTANT_5="part.panel.description";
	
	@RBEntry("Part Information")
	public static final String CONSTANT_6="part.panel.title";
	
	@RBEntry("Part Information action")
	public static final String CONSTANT_7="part.panel.tooltip";
	
	@RBEntry("attributes.gif")
	@RBPseudo(false)
	public static final String CONSTANT_8="part.panel.icon";	
	
	@RBEntry("Select Object")
	public static final String CONSTANT_9="part.selectObject.description";
	 
	@RBEntry("Select Object")
	public static final String CONSTANT_10="part.selectObject.title";
	
	@RBEntry("Set Attributes")
	public static final String CONSTANT_11="part.setAttribute.description";
	
	@RBEntry("Set Attributes")
	public static final String CONSTANT_12="part.setAttribute.title";
	
	@RBEntry("Create Object")
	public static final String CONSTANT_13="part.createPartCustom2.description";
	
	@RBEntry("Create Object")
	public static final String CONSTANT_14="part.createPartCustom2.title";
	
	@RBEntry("Create Object action")
	public static final String CONSTANT_15="part.createPartCustom2.tooltip";
	
	@RBEntry("create_tbar.gif")
	@RBPseudo(false)
	public static final String CONSTANT_16="part.createPartCustom2.icon";	
	
	@RBEntry("Select Object")
	public static final String CONSTANT_17="part.selectObject2.description";
	  
	@RBEntry("Select Object")
	public static final String CONSTANT_18="part.selectObject2.title";
	

	@RBEntry("Set Attributes")
	public static final String CONSTANT_19="part.setAttribute2.description";
	 
	@RBEntry("Set Attributes")
	public static final String CONSTANT_20="part.setAttribute2.title";
	
	
	}



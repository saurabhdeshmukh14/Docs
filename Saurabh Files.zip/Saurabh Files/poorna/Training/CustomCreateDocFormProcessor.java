package com.itc.processor;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.doc.forms.CreateDocFormProcessor;

import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionReference;
import wt.vc.wip.WorkInProgressHelper;

public class CustomCreateDocFormProcessor extends CreateDocFormProcessor {
	
	
	@Override
	public FormResult postProcess(NmCommandBean commandBean, List<ObjectBean> list) throws WTException {
		// TODO Auto-generated method stub
		try {
		WTDocument document = null;
		for (Iterator localIterator = list.iterator(); localIterator.hasNext(); )
		document = (WTDocument)(((ObjectBean)localIterator.next()).getObject());
		HttpServletRequest request = commandBean.getRequest();
		Enumeration em = request.getParameterNames();
		String temp =  "";
		while(em.hasMoreElements())
		{ 
		temp=	em.nextElement().toString();
		System.out.println(temp);
		if(temp.contains("MyPicker")&& (temp!= null)) {
			temp =request.getParameter(temp);
		System.out.println("temp2-----"+temp);
		WTPart part =(WTPart) fromReferenceToObject(temp);
		part =(WTPart) WorkInProgressHelper.service.checkout(part, WorkInProgressHelper.service.getCheckoutFolder(), "Checking out to Doc").getWorkingCopy();
		WTPartDescribeLink link = WTPartDescribeLink.newWTPartDescribeLink(part, document);
		PersistenceHelper.manager.save(link);
		WorkInProgressHelper.service.checkin(part,"Check in after Document attach");
		}
		}
		}catch(WTException e) {
			e.printStackTrace();
		}catch(WTPropertyVetoException e) {
			e.printStackTrace();
		}
		return super.postProcess(commandBean, list);
	}
	
	
	private Persistable fromReferenceToObject(String objectReference) throws WTException {
		final ReferenceFactory factory = new ReferenceFactory();
		final VersionReference objRef = (VersionReference) factory.getReference(objectReference);
		return (objRef.getObject());
	}
	
	

}

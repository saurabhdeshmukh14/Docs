package com.itc.training;

import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import java.util.*;
import wt.util.WTException;

public class Test extends DefaultObjectFormProcessor {
	@Override
	public FormResult doOperation(NmCommandBean clientData,List <ObjectBean> objectbeans) throws WTException
	{
		//Object obj = clientData.getPrimaryOid().getWtRef().getObject();
		FormResult formresult = new FormResult();
		formresult.setStatus(FormProcessingStatus.SUCCESS);
		return formresult;
	}
	
}
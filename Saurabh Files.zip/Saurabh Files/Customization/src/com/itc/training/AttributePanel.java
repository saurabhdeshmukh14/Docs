package com.itc.training;

import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.core.ui.resources.ComponentType;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.AttributeConfig;
import com.ptc.mvc.components.AttributePanelConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.GroupConfig;

import wt.part.WTPart;
import wt.util.WTException;
@ComponentBuilder("com.itc.training.AttributePanel")
public class AttributePanel extends AbstractComponentBuilder{

	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		Object contextObject = arg1.getContextObject();
		WTPart part = (WTPart) contextObject;
		return part;
	}

	/*@Override
	public ComponentConfig buildComponentConfig(ComponentParams var1) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		AttributePanelConfig panel = factory.newAttributePanelConfig();
		//panel.setComponentMode(ComponentMode.VIEW); 
	GroupConfig config=factory.newGroupConfig("Part Attributes");
		AttributeConfig nameAttribute = factory.newAttributeConfig("name");
		nameAttribute.setLabel("Name");
		AttributeConfig memberAttribute = factory.newAttributeConfig("number");
		memberAttribute.setLabel("Number"); 

		AttributeConfig creatorAttribute = factory.newAttributeConfig("iterationInfo.creator");
		creatorAttribute.setLabel("Creator");

		AttributeConfig lastModifiedAttribute = factory.newAttributeConfig("thePersistInfo.modifyStamp");
		lastModifiedAttribute.setLabel("Last Modified");
		AttributeConfig versionAttribute = factory.newAttributeConfig("versionInfo.identifier.versionId");
		versionAttribute.setLabel("Version");

		// attributePanel.setView("/training/AttributePanel.jsp");
		//attributePanel.setView("/carambola/attributePanel/simpleAttributePanelWithAbout.jsp");
		//panel.setComponentType(ComponentType.INFO_ATTRIBUTES_TABLE);
		panel.setView("/components/simpleAttributePanel.jsp"); 

		panel.addComponent(nameAttribute);
		panel.addComponent(memberAttribute);
		panel.addComponent(creatorAttribute);
		panel.addComponent(lastModifiedAttribute); 
		panel.addComponent(versionAttribute);
		panel.setId("attributePanel");
		panel.setLabel("Part Attribute Panel");
		panel.setComponentMode(ComponentMode.VIEW);
		panel.setComponentType(ComponentType.INFO_ATTRIBUTES_TABLE);

		return panel;*/
	
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams var1) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		AttributePanelConfig panel = factory.newAttributePanelConfig();
		//panel.setComponentMode(ComponentMode.VIEW); 
		GroupConfig config=factory.newGroupConfig("Part Attributes");
		GroupConfig config1=factory.newGroupConfig("Other Attributes");
		AttributeConfig nameAttribute = factory.newAttributeConfig("name");
		nameAttribute.setLabel("Name");
		AttributeConfig memberAttribute = factory.newAttributeConfig("number");
		memberAttribute.setLabel("Number"); 

		AttributeConfig creatorAttribute = factory.newAttributeConfig("iterationInfo.creator");
		creatorAttribute.setLabel("Creator");

		AttributeConfig lastModifiedAttribute = factory.newAttributeConfig("thePersistInfo.modifyStamp");
		lastModifiedAttribute.setLabel("Last Modified");
		AttributeConfig versionAttribute = factory.newAttributeConfig("versionInfo.identifier.versionId");
		versionAttribute.setLabel("Version");
		AttributeConfig combo = factory.newAttributeConfig("Combo");
		combo.setLabel("Combo");
		AttributeConfig source = factory.newAttributeConfig("Source");
		source.setLabel("Source");
		// attributePanel.setView("/training/AttributePanel.jsp");
		//attributePanel.setView("/carambola/attributePanel/simpleAttributePanelWithAbout.jsp");
		//panel.setComponentType(ComponentType.INFO_ATTRIBUTES_TABLE);
		config.addComponent(nameAttribute);
		config.addComponent(memberAttribute);
		config.addComponent(lastModifiedAttribute);
		config.addComponent(versionAttribute);
		config1.addComponent(combo);
		config1.addComponent(source);
		panel.setView("/components/attributePanel.jsp"); 

		panel.addComponent(config);
		panel.addComponent(config1);
		
		panel.setId("attributePanel");
		panel.setLabel("Part Attribute Panel");
		panel.setComponentMode(ComponentMode.VIEW);
		panel.setComponentType(ComponentType.INFO_ATTRIBUTES_TABLE);

		return panel;
	}

}

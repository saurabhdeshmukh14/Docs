/**
 * 
 */
package com.itc.builder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.components.descriptor.DescriptorConstants.TableTreeProperties;
import com.ptc.jca.mvc.components.JcaTreeConfig;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.ComponentResultProcessor;
import com.ptc.mvc.components.TreeDataBuilderAsync;
import com.ptc.mvc.components.TreeNode;
import com.ptc.mvc.components.ds.DataSourceMode;

import wt.part.WTPart;
import wt.util.WTException;

@ComponentBuilder("SampleTreeBuilder")
public class SampleTreeBuilder extends AbstractComponentBuilder implements TreeDataBuilderAsync {
	SampleTreeHandlerAdapter sampleHandler;

	/**
	 * @param arg0
	 * @param arg1
	 * @return
	 * @throws Exception
	 */
	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		return new SampleTreeHandlerAdapter();
	}

	/**
	 * @param arg0
	 * @return
	 * @throws WTException
	 */
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		JcaTreeConfig tree = (JcaTreeConfig)factory.newTreeConfig();
		tree.setDataSourceMode(DataSourceMode.ASYNCHRONOUS);
		tree.setExpansionLevel(TableTreeProperties.NO_EXPAND);
		tree.setLabel("Custom Tree");
		tree.addComponent(factory.newColumnConfig("type_icon", true));
		final ColumnConfig typeConfig = factory.newColumnConfig("type_icon", true);
		typeConfig.setWidth(20);
		final ColumnConfig numberConfig = factory.newColumnConfig("number", true);
		numberConfig.setWidth(80);
		numberConfig.setInfoPageLink(true);
		numberConfig.setLabel("Number");
		tree.addComponent(numberConfig);
		final ColumnConfig infoConfig = factory.newColumnConfig("infoPageAction", true);
		infoConfig.setWidth(40);
		infoConfig.setInfoPageLink(true);
		tree.addComponent(infoConfig);
		final ColumnConfig nameConfig = factory.newColumnConfig("name", true);
		nameConfig.setWidth(80);
		nameConfig.setLabel("Name");
		tree.addComponent(nameConfig);
		final ColumnConfig creatorConfig = factory.newColumnConfig("creatorName", true);
		creatorConfig.setWidth(80);
		creatorConfig.setLabel("Created By");
		tree.addComponent(creatorConfig);
		final ColumnConfig versionConfig = factory.newColumnConfig("version", true);
		versionConfig.setWidth(80);
		versionConfig.setLabel("Version");
		tree.addComponent(versionConfig);
		final ColumnConfig modifyConfig = factory.newColumnConfig("thePersistInfo.modifyStamp", true);
		modifyConfig.setWidth(80);
		modifyConfig.setLabel("Last Modified");
		tree.addComponent(modifyConfig);
		final ColumnConfig viewConfig = factory.newColumnConfig("ViewName", true);
		viewConfig.setWidth(80);
		tree.addComponent(viewConfig);
		viewConfig.setLabel("View Name");
		final ColumnConfig stateConfig = factory.newColumnConfig("state", true);
		stateConfig.setWidth(80);
		stateConfig.setLabel("State");
		tree.addComponent(stateConfig);
		tree.setNodeColumn("number");
		tree.setShowTreeLines(true);
		//tree.setView("/components/tree.jsp");
		return tree;
	}

	@Override
	@SuppressWarnings(value = {"rawtypes"})
	public void buildNodeData(Object node, ComponentResultProcessor resultProcessor) throws Exception {
		if (node == TreeNode.RootNode) {
			sampleHandler = new SampleTreeHandlerAdapter(resultProcessor.getParams());
			resultProcessor.addElements(sampleHandler.getRootNodes());
		} else {
			System.out.println("Node Class--"+node.getClass());
			List<WTPart> nodeList = new ArrayList<WTPart>();
			nodeList.add((WTPart) node);
			Map<Object, List> map = sampleHandler.getNodes(nodeList);
			Set<Object> set = map.keySet();
			for (Object key : set) {
				resultProcessor.addElements(map.get(key));
			}
		}
	}

}

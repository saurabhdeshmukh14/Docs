package com.itc.training;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.SuggestTextBox;
import com.ptc.core.ui.resources.ComponentMode;

import wt.util.WTException;

public class SuggestTextUtility extends DefaultDataUtility {
	@Override 
	public Object getDataValue(String componentId, Object datum, ModelContext modelContext) throws WTException {
		SuggestTextBox box = new SuggestTextBox(componentId,"suggestBoxHelper");
		if(modelContext.getDescriptorMode().equals(ComponentMode.CREATE)||modelContext.getDescriptorMode().equals(ComponentMode.EDIT)){
		ComponentDescriptor descriptor = modelContext.getDescriptor();
		String modelAttribute = descriptor.getModelAttributeString();
		Object value = modelContext.getRawValue();
		String columnName = AttributeDataUtilityHelper.getColumnName(modelAttribute, datum, modelContext);
		
		box.setMinChars(3);
		box.setColumnName(columnName);
		box.setUseAltHiddenFieldInFormProcssor(true);
		box.setValue(box.getParm((String) value));
		}
		return box;
		
	}
	
}

package com.itc.training;

import java.util.Locale;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;

import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.util.WTException;

public class SetStateValidator extends DefaultUIComponentValidator {
@Override
public UIValidationResultSet performFullPreValidation(UIValidationKey validationKey,
		UIValidationCriteria validationCriteria, Locale paramLocale) throws WTException {
	// TODO Auto-generated method stub
	UIValidationResultSet resultSet = UIValidationResultSet.newInstance();
	Persistable localPersistable = null;
	System.out.println("SetStateValidator is called");
	if (validationCriteria != null) {
		WTReference localWTReference = validationCriteria.getContextObject();
		localPersistable = localWTReference.getObject();
	}
	if ((localPersistable != null) && (localPersistable instanceof WTPart)) {
		State localState = ((LifeCycleManaged) localPersistable)
				.getLifeCycleState();
		if (!(State.toState("RELEASED").equals(localState))) {
			resultSet.addResult(UIValidationResult.newInstance(
					validationKey, UIValidationStatus.HIDDEN));
		} else {
			resultSet.addResult(UIValidationResult.newInstance(
					validationKey, UIValidationStatus.ENABLED));
		}
	}
	return resultSet;
}
}

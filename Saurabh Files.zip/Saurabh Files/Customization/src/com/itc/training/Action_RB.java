package com.itc.training;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.itc.training.Action_RB")
public class Action_RB extends WTListResourceBundle {
	 @RBEntry("ViewJSP")
	            //@RBComment("ViewJSP")
	  public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC = "saurabh.ViewJSP.description";
	            
	  
	   @RBEntry("export_BOM_to_CEDM.png")
	     public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON = "saurabh.ViewJSP.icon";
	                        
	          @RBEntry("This action is to view")
	             public static final String LOCK_CI_BY_CHANGE_NOTICE_TOOLTIP = "saurabh.ViewJSP.tooltip";
	          
	   @RBEntry("Custom_Part")
	            //@RBComment("ViewJSP")
	  public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC1 = "pqr.createPartxyz.description";
	            
	  
	   @RBEntry("export_BOM_to_CEDM.png")
	     public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON1 = "pqr.createPartxyz.icon";
	             
	          
	   @RBEntry("Demo_Table")
	            //@RBComment("ViewJSP")
	  public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC2 = "object.demoTable.description";
	            
	  
	   @RBEntry("table_saveasdefaultview.png")
	     public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON2 = "object.demoTable.icon";
	   
	   @RBEntry("Test Table")
       //@RBComment("ViewJSP")
	   	public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC3 = "part.test_table.description";
       

	   @RBEntry("table_saveasdefaultview.png")
	   public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON3 = "part.test_table.icon";
	   
	   @RBEntry("Create Custom Wizard")
       
	   	public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC4 = "part.createPartCustom.description";
       

	   @RBEntry("attributes.gif")
	   public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON4 = "part.createPartCustom.icon";
	   
	   @RBEntry("Create Custom 2")
       
	   	public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC5 = "part.createPartCustom2.description";
       

	   @RBEntry("create_tbar.gif")
	   public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON5 = "part.createPartCustom2.icon";
	   
	   @RBEntry("Select Object")
       public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC6 = "part.selectObject2.description";
       

	   @RBEntry("table_saveasdefaultview.png")
	   public static final String LOCK_CI_BY_CHANGE_NOTICE_ICON6 = "part.selectObject2.icon";
	   
	   @RBEntry("Set Attributes")
		public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC7="part.setAttribute2.description";
		 
		@RBEntry("Set Attributes")
		public static final String LOCK_CI_BY_CHANGE_NOTICE_TITLE7="part.setAttribute2.title";
		
		@RBEntry("Select Object")
		public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC8="part.selectObject.description";
		 
		@RBEntry("Select Object")
		public static final String LOCK_CI_BY_CHANGE_NOTICE_TITLE8="part.selectObject.title";
		
		@RBEntry("Set Attributes")
		public static final String LOCK_CI_BY_CHANGE_NOTICE_DESC9="part.setAttribute.description";
		
		@RBEntry("Set Attributes")
		public static final String LOCK_CI_BY_CHANGE_NOTICE_TITLE9="part.setAttribute.title";
		
				
		@RBEntry("<U class='mnemonic' >C</U>ustom")
		public static final String PRIVATE_CONSTANT_1011 = "object.Custom.description";
	  
}
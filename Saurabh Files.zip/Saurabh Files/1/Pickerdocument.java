package com.itc.training;

import java.util.Map;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.PickerRenderConfigs;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.components.rendering.guicomponents.RadioButton;
import com.ptc.core.components.rendering.guicomponents.RadioButtonGroup;
import com.ptc.windchill.enterprise.doc.forms.CreateDocFormProcessor;

import wt.util.WTException;

public class Pickerdocument extends DefaultDataUtility {
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException
	{
		ComponentDescriptor componentdescriptor = paramModelContext.getDescriptor();
		Map<Object, Object> map = componentdescriptor.getProperties();
		Object value = paramModelContext.getRawValue();
		System.out.println("Value--"+(String)value);
		String attLabelName = getLabel(paramString, paramModelContext);
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.PICKER_ID, "pickerdocid");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.OBJECT_TYPE, "wt.part.WTPart");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.PICKER_TITLE, "Search Part");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.READ_ONLY_TEXTBOX, "true");
		PickerRenderConfigs.setDefaultPickerProperty(map, "showTypePicker",
				"false"); 
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.COMPONENT_ID, "pickerdocid");
		PickerRenderConfigs.setDefaultPickerProperty(map, "defaultHiddenValue",
				(String) value);
		PickerRenderConfigs.setDefaultPickerProperty(map, "pickedAttributes",
				"name");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				"includeTypeInstanceId", "true");
		
		PickerInputComponent pickerinputcomponent = new PickerInputComponent(
				attLabelName, (String) value,
				PickerRenderConfigs.getPickerConfigs(map), 60);
		pickerinputcomponent.setColumnName(AttributeDataUtilityHelper
				.getColumnName(paramString, paramObject, paramModelContext));
		pickerinputcomponent.setId(paramString);
		pickerinputcomponent.setName(paramString);
		pickerinputcomponent.setRequired(AttributeDataUtilityHelper
				.isInputRequired(paramModelContext));
		return pickerinputcomponent;
	}
}

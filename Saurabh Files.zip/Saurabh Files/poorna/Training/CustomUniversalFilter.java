package com.itc.validator;

import com.ptc.core.ui.validation.DefaultUniversalValidationFilter;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationStatus;

public class CustomUniversalFilter extends DefaultUniversalValidationFilter {

@Override
public UIValidationStatus preValidateAction(UIValidationKey paramUIValidationKey,
		UIValidationCriteria paramUIValidationCriteria) {
	// TODO Auto-generated method stub
	System.out.println("Universal Filter is called" + paramUIValidationKey);
	return super.preValidateAction(paramUIValidationKey, paramUIValidationCriteria);
}
}
